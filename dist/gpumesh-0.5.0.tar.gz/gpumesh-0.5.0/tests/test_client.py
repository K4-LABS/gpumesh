"""Tests for client.py - progress bar and job display functionality."""

import json
import sys
from unittest.mock import patch, MagicMock
import pytest

from gpumesh.client import _esc, _bar, _get_workers, print_job, wait_for_job


class TestEsc:
    """Tests for _esc() ANSI escape code function."""

    def test_esc_returns_code_when_ansi_enabled(self):
        """Returns escape code when ANSI is enabled."""
        with patch("gpumesh.client._ANSI", True):
            assert _esc("1m") == "1m"
            assert _esc("0m") == "0m"
            assert _esc("32m") == "32m"

    def test_esc_returns_empty_when_ansi_disabled(self):
        """Returns empty string when ANSI is disabled."""
        with patch("gpumesh.client._ANSI", False):
            assert _esc("1m") == ""
            assert _esc("0m") == ""
            assert _esc("32m") == ""

    def test_esc_with_various_codes(self):
        """Tests various ANSI codes."""
        with patch("gpumesh.client._ANSI", True):
            assert _esc("31m") == "31m"  # Red
            assert _esc("33m") == "33m"  # Yellow
            assert _esc("36m") == "36m"  # Cyan


class TestBar:
    """Tests for _bar() progress bar builder."""

    def test_bar_empty_progress(self):
        """Returns empty bar when total is 0."""
        result = _bar(0, 10)
        assert result == "░" * 20

    def test_bar_full_progress(self):
        """Returns full bar when done equals total."""
        result = _bar(10, 10)
        assert result == "█" * 20

    def test_bar_half_progress(self):
        """Returns half-filled bar at 50%."""
        result = _bar(5, 10)
        assert result == "█" * 10 + "░" * 10

    def test_bar_custom_width(self):
        """Returns bar with custom width."""
        result = _bar(1, 4, width=10)
        assert len(result) == 10
        assert result == "█" * 2 + "░" * 8

    def test_bar_zero_done(self):
        """Returns all empty when done is 0."""
        result = _bar(0, 100, width=10)
        assert result == "░" * 10

    def test_bar_width_one_partial(self):
        """Returns partial bar when width is 1 and progress < 50%."""
        result = _bar(1, 4, width=1)
        assert result == "░"

    def test_bar_width_one_full(self):
        """Returns partial bar when width is 1 and progress is 50% (int truncation)."""
        result = _bar(2, 4, width=1)
        assert result == "░"

    def test_bar_width_one_above_half(self):
        """Returns full bar when width is 1 and progress is 100%."""
        result = _bar(4, 4, width=1)
        assert result == "█"

    def test_bar_width_zero(self):
        """Returns empty string when width is 0."""
        result = _bar(5, 10, width=0)
        assert result == ""


class TestGetWorkers:
    """Tests for _get_workers() function."""

    def test_get_workers_success(self):
        """Returns worker dict on successful API call."""
        mock_mesh = MagicMock()
        mock_mesh.call.return_value = {
            "workers": [
                {"id": "w1", "hostname": "PC1", "device": "cuda", "score": 85.0},
                {"id": "w2", "hostname": "PC2", "device": "cpu", "score": 10.0}
            ]
        }
        with patch("gpumesh.client.MeshClient", return_value=mock_mesh):
            result = _get_workers("http://localhost:8000", "token123")
            assert len(result) == 2
            assert "w1" in result
            assert "w2" in result
            assert result["w1"]["hostname"] == "PC1"

    def test_get_workers_connection_error(self):
        """Returns empty dict on connection error."""
        mock_mesh = MagicMock()
        mock_mesh.call.side_effect = ConnectionError("Connection refused")
        with patch("gpumesh.client.MeshClient", return_value=mock_mesh):
            result = _get_workers("http://localhost:8000", "token123")
            assert result == {}

    def test_get_workers_os_error(self):
        """Returns empty dict on OS error."""
        mock_mesh = MagicMock()
        mock_mesh.call.side_effect = OSError("Network unreachable")
        with patch("gpumesh.client.MeshClient", return_value=mock_mesh):
            result = _get_workers("http://localhost:8000", "token123")
            assert result == {}

    def test_get_workers_json_error(self):
        """Returns empty dict on JSON decode error."""
        mock_mesh = MagicMock()
        mock_mesh.call.side_effect = json.JSONDecodeError("Invalid JSON", "doc", 0)
        with patch("gpumesh.client.MeshClient", return_value=mock_mesh):
            result = _get_workers("http://localhost:8000", "token123")
            assert result == {}

    def test_get_workers_empty_workers(self):
        """Returns empty dict when no workers."""
        mock_mesh = MagicMock()
        mock_mesh.call.return_value = {"workers": []}
        with patch("gpumesh.client.MeshClient", return_value=mock_mesh):
            result = _get_workers("http://localhost:8000", "token123")
            assert result == {}


class TestPrintJob:
    """Tests for print_job() function."""

    def test_print_job_running(self, capsys):
        """Prints running job status."""
        job = {
            "id": "j123",
            "name": "test_job",
            "finished": False,
            "counts": {"running": 2, "pending": 3},
            "tasks": [
                {"id": "t1", "status": "running", "cost": 1.0, "worker_id": "w1", "result": None, "error": None},
                {"id": "t2", "status": "pending", "cost": 1.0, "worker_id": None, "result": None, "error": None}
            ]
        }
        print_job(job)
        captured = capsys.readouterr()
        assert "test_job" in captured.out
        assert "j123" in captured.out
        assert "running" in captured.out
        assert "worker=w1" in captured.out

    def test_print_job_finished(self, capsys):
        """Prints finished job status."""
        job = {
            "id": "j456",
            "name": "completed_job",
            "finished": True,
            "counts": {"done": 2, "failed": 1},
            "tasks": [
                {"id": "t1", "status": "done", "cost": 1.0, "worker_id": "w1", "result": {"acc": 0.9}, "error": None},
                {"id": "t2", "status": "failed", "cost": 1.0, "worker_id": "w2", "result": None, "error": "timeout"}
            ]
        }
        print_job(job)
        captured = capsys.readouterr()
        assert "completed_job" in captured.out
        assert "finished" in captured.out
        assert "result: " in captured.out
        assert "error: timeout" in captured.out

    def test_print_job_with_results(self, capsys):
        """Prints task results."""
        job = {
            "id": "j789",
            "name": "result_job",
            "finished": True,
            "counts": {"done": 1},
            "tasks": [
                {"id": "t1", "status": "done", "cost": 2.0, "worker_id": "w1", "result": {"value": 42}, "error": None}
            ]
        }
        print_job(job)
        captured = capsys.readouterr()
        assert '{"value": 42}' in captured.out


class TestWaitForJob:
    """Tests for wait_for_job() function."""

    def test_wait_for_job_immediate_finish(self, capsys):
        """Returns immediately when job is finished."""
        finished_job = {
            "id": "j123",
            "name": "test",
            "finished": True,
            "counts": {"done": 1},
            "tasks": [{"id": "t1", "status": "done", "cost": 1.0, "worker_id": "w1", "result": {"val": 1}, "error": None}]
        }
        with patch("gpumesh.client.get_status", return_value=finished_job), \
             patch("gpumesh.client._get_workers", return_value={"w1": {"hostname": "PC1", "device": "cuda"}}):
            result = wait_for_job("http://localhost:8000", "token", "j123", poll=0.01)
            assert result["finished"] is True
            assert result["id"] == "j123"

    def test_wait_for_job_polls_until_finished(self, capsys):
        """Polls multiple times before job finishes."""
        running_job = {
            "id": "j123", "name": "test", "finished": False,
            "counts": {"running": 1},
            "tasks": [{"id": "t1", "status": "running", "cost": 1.0, "worker_id": "w1", "result": None, "error": None}]
        }
        finished_job = {
            "id": "j123", "name": "test", "finished": True,
            "counts": {"done": 1},
            "tasks": [{"id": "t1", "status": "done", "cost": 1.0, "worker_id": "w1", "result": {"val": 1}, "error": None}]
        }
        with patch("gpumesh.client.get_status", side_effect=[running_job, finished_job]), \
             patch("gpumesh.client._get_workers", return_value={"w1": {"hostname": "PC1", "device": "cuda"}}):
            result = wait_for_job("http://localhost:8000", "token", "j123", poll=0.01)
            assert result["finished"] is True

    def test_wait_for_job_shows_progress(self, capsys):
        """Displays progress information during wait."""
        progress_job = {
            "id": "j123", "name": "progress_job", "finished": False,
            "counts": {"pending": 2, "running": 0}, "tasks": []
        }
        finished_job = {
            "id": "j123", "name": "progress_job", "finished": True,
            "counts": {"done": 2},
            "tasks": [{"id": "t1", "status": "done", "cost": 1.0, "worker_id": "w1", "result": {}, "error": None}]
        }
        with patch("gpumesh.client.get_status", side_effect=[progress_job, finished_job]), \
             patch("gpumesh.client._get_workers", return_value={}), \
             patch("sys.stdout.write") as mock_write:
            result = wait_for_job("http://localhost:8000", "token", "j123", poll=0.01)
            # Verify write was called (progress was displayed)
            assert mock_write.call_count > 0

    def test_wait_for_job_with_failed_tasks(self, capsys):
        """Handles failed tasks in progress display."""
        job = {
            "id": "j123",
            "name": "fail_job",
            "finished": True,
            "counts": {"done": 1, "failed": 1},
            "tasks": [
                {"id": "t1", "status": "done", "cost": 1.0, "worker_id": "w1", "result": {}, "error": None},
                {"id": "t2", "status": "failed", "cost": 1.0, "worker_id": "w1", "result": None, "error": "crash"}
            ]
        }
        with patch("gpumesh.client.get_status", return_value=job), \
             patch("gpumesh.client._get_workers", return_value={}), \
             patch("sys.stdout.write"):
            result = wait_for_job("http://localhost:8000", "token", "j123", poll=0.01)
            assert result["finished"] is True
            assert result["counts"]["failed"] == 1
