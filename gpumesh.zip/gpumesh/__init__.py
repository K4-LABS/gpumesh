"""gpumesh - distributed compute sharing over a mesh of volunteer machines."""

__version__ = "0.1.0"
