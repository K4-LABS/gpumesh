"""gpumesh command line interface.

  gpumesh serve  [--port 8000] [--token SECRET] [--public]
  gpumesh join   URL [--token SECRET]
  gpumesh submit SCRIPT --payloads FILE [--wait] --url URL [--token SECRET]
  gpumesh status JOB_ID --url URL [--token SECRET]
  gpumesh workers --url URL [--token SECRET]
"""

import argparse
import os
import secrets
import socket

from . import client, server, tunnel, worker


def _lan_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def cmd_serve(args):
    token = args.token or secrets.token_urlsafe(12)
    httpd = server.serve("0.0.0.0", args.port, args.db, token)
    ip = _lan_ip()
    print(f"[mesh] coordinator listening on 0.0.0.0:{args.port}")
    print(f"[mesh] token: {token}")
    print(f"[mesh] LAN join command:")
    print(f"       gpumesh join http://{ip}:{args.port} --token {token}")
    if args.public:
        tunnel.open_tunnel(args.port)
    print("[mesh] Ctrl+C to stop")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[mesh] shutting down")
        httpd.gpumesh_stop.set()
        httpd.shutdown()


def cmd_join(args):
    worker.run_worker(args.url, args.token, task_timeout=args.timeout)


def cmd_submit(args):
    job_id = client.submit_job(args.url, args.token, args.script,
                               args.payloads, name=args.name)
    print(f"[client] submitted job {job_id}")
    if args.wait:
        job = client.wait_for_job(args.url, args.token, job_id)
        client.print_job(job)
    else:
        print(f"[client] check progress: gpumesh status {job_id}"
              f" --url {args.url} --token {args.token}")


def cmd_status(args):
    job = client.get_status(args.url, args.token, args.job_id)
    client.print_job(job)


def cmd_workers(args):
    from .worker import MeshClient

    resp = MeshClient(args.url, args.token).call("GET", "/api/workers")
    for w in resp["workers"]:
        state = "alive" if w["alive"] else "dead"
        print(f"  {w['id']}  {w['hostname']:<20} {w['device']:<5} "
              f"score={w['score']:<10} [{state}]")
    if not resp["workers"]:
        print("  (no workers yet)")


def _add_conn_args(p):
    p.add_argument("--url", default=os.environ.get("GPUMESH_URL", ""),
                   help="coordinator URL (or set GPUMESH_URL)")
    p.add_argument("--token", default=os.environ.get("GPUMESH_TOKEN", ""),
                   help="shared auth token (or set GPUMESH_TOKEN)")


def main():
    ap = argparse.ArgumentParser(prog="gpumesh",
                                 description="borrow your friends' GPUs")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("serve", help="start a coordinator on this machine")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--db", default="gpumesh.db")
    p.add_argument("--token", default="", help="auth token (random if omitted)")
    p.add_argument("--public", action="store_true",
                   help="expose a public URL via ngrok")
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser("join", help="offer this machine's compute to a mesh")
    p.add_argument("url", help="coordinator URL")
    p.add_argument("--token", default=os.environ.get("GPUMESH_TOKEN", ""))
    p.add_argument("--timeout", type=float, default=240.0,
                   help="per-task wall clock limit in seconds")
    p.set_defaults(func=cmd_join)

    p = sub.add_parser("submit", help="submit a job to the mesh")
    p.add_argument("script", help="python script to run for every payload")
    p.add_argument("--payloads", required=True,
                   help="JSON file: list of payload objects (each may set 'cost')")
    p.add_argument("--name", default="")
    p.add_argument("--wait", action="store_true", help="block until finished")
    _add_conn_args(p)
    p.set_defaults(func=cmd_submit)

    p = sub.add_parser("status", help="show job progress and results")
    p.add_argument("job_id")
    _add_conn_args(p)
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("workers", help="list workers in the mesh")
    _add_conn_args(p)
    p.set_defaults(func=cmd_workers)

    args = ap.parse_args()
    if hasattr(args, "url") and not args.url and args.cmd != "serve":
        ap.error("--url required (or set GPUMESH_URL)")
    args.func(args)


if __name__ == "__main__":
    main()
