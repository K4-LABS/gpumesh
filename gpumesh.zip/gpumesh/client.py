"""Client-side helpers: submit jobs, poll status, pretty-print results."""

import json
import sys
import time

from .worker import MeshClient


def submit_job(url: str, token: str, script_path: str, payloads_path: str,
               name: str = "") -> str:
    with open(script_path) as f:
        script = f.read()
    with open(payloads_path) as f:
        payloads = json.load(f)
    if not isinstance(payloads, list):
        raise SystemExit("payloads file must contain a JSON list")

    mesh = MeshClient(url, token)
    resp = mesh.call("POST", "/api/jobs", {
        "name": name or script_path,
        "script": script,
        "payloads": payloads,
    })
    return resp["job_id"]


def get_status(url: str, token: str, job_id: str) -> dict:
    return MeshClient(url, token).call("GET", f"/api/jobs/{job_id}")


def wait_for_job(url: str, token: str, job_id: str, poll: float = 3.0) -> dict:
    while True:
        job = get_status(url, token, job_id)
        counts = job["counts"]
        total = sum(counts.values())
        done = counts.get("done", 0) + counts.get("failed", 0)
        sys.stdout.write(f"\r[job {job_id}] {done}/{total} tasks finished "
                         f"({counts})   ")
        sys.stdout.flush()
        if job["finished"]:
            print()
            return job
        time.sleep(poll)


def print_job(job: dict):
    print(f"job: {job['name']} ({job['id']})  finished={job['finished']}")
    for t in job["tasks"]:
        line = f"  task {t['id']}  [{t['status']}]  cost={t['cost']}"
        if t["worker_id"]:
            line += f"  worker={t['worker_id']}"
        print(line)
        if t["result"] is not None:
            print(f"    result: {json.dumps(t['result'])}")
        if t["error"]:
            print(f"    error: {t['error']}")
