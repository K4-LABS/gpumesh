"""Optional public URL via ngrok (needs `pip install pyngrok` + an ngrok
account). Without it the coordinator is LAN-only, which is fine for
machines on the same Wi-Fi."""


def open_tunnel(port: int):
    try:
        from pyngrok import ngrok
    except ImportError:
        print("[mesh] pyngrok not installed - LAN only.")
        print("[mesh] for a public URL: pip install pyngrok, or run"
              f" `ngrok http {port}` in another terminal.")
        return None
    tunnel = ngrok.connect(port, "http")
    print(f"[mesh] public URL: {tunnel.public_url}")
    print(f"[mesh] friends join with: gpumesh join {tunnel.public_url}"
          " --token <TOKEN>")
    return tunnel
